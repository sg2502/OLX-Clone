import React from "react";
import './signuploading.css'
const SignUpLoading = () => {
  return (
    <div className="signup-loading">
      {/* <h1 className="title">Loading...</h1> */}
      <div className="rainbow-marker-loader"></div>
    </div>
  );
};

export default SignUpLoading;
